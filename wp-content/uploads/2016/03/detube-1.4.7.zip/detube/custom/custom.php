<?php
/**
 * Custom PHP Code by Theme User
 *
 * NOTE: This file only work if it's in the theme root directory.
 */